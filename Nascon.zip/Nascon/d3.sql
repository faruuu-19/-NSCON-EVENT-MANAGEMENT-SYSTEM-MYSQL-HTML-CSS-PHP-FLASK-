CREATE DATABASE d3;
USE d3;

CREATE TABLE user (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20)
);

CREATE TABLE admin (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);

CREATE TABLE event_organizer (
    organizer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);

CREATE TABLE participant (
    participant_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);

CREATE TABLE sponsor (
    sponsor_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    company_name VARCHAR(100) NOT NULL,
    sponsorship_level ENUM('title', 'gold', 'silver', 'media_partner') NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);

CREATE TABLE judge (
    judge_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    expertise VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);
CREATE TABLE event_category (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE venue (
    venue_id INT PRIMARY KEY AUTO_INCREMENT,
    venue_name VARCHAR(100) NOT NULL,
    capacity INT NOT NULL,
    location TEXT NOT NULL
);

CREATE TABLE nascon_events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(100) NOT NULL,
    description TEXT,
    category_id INT,
    rules TEXT,
    max_participants INT,
    registration_fee DECIMAL(10,2),
    event_date DATETIME NOT NULL,
    venue_id INT,
    organizer_id INT,
    FOREIGN KEY (category_id) REFERENCES event_category(category_id),
    FOREIGN KEY (venue_id) REFERENCES venue(venue_id),
    FOREIGN KEY (organizer_id) REFERENCES event_organizer(organizer_id)
);

CREATE TABLE event_schedule (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    venue_id INT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    FOREIGN KEY (event_id) REFERENCES nascon_events(event_id),
    FOREIGN KEY (venue_id) REFERENCES venue(venue_id),
    CONSTRAINT unique_venue_schedule UNIQUE (venue_id, start_time, end_time)
);

-- 🔁 Rounds Table (Missing Before)
CREATE TABLE round (
    round_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    round_name VARCHAR(50) NOT NULL,
    round_number INT,
    round_date DATETIME,
    FOREIGN KEY (event_id) REFERENCES nascon_events(event_id)
);
CREATE TABLE team (
    team_id INT PRIMARY KEY AUTO_INCREMENT,
    team_name VARCHAR(100) NOT NULL
);

CREATE TABLE event_registration (
    registration_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    participant_id INT DEFAULT NULL,
    team_id INT DEFAULT NULL,
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES nascon_events(event_id),
    FOREIGN KEY (participant_id) REFERENCES participant(participant_id),
    FOREIGN KEY (team_id) REFERENCES team(team_id),
    CONSTRAINT chk_participant_or_team CHECK (participant_id IS NOT NULL OR team_id IS NOT NULL)
);
CREATE TABLE accommodation (
    accommodation_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50),
    price_per_night DECIMAL(10,2),
    capacity INT,
    location TEXT
);

CREATE TABLE room_allocation (
    allocation_id INT PRIMARY KEY AUTO_INCREMENT,
    participant_id INT NOT NULL,
    accommodation_id INT NOT NULL,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    FOREIGN KEY (participant_id) REFERENCES participant(participant_id),
    FOREIGN KEY (accommodation_id) REFERENCES accommodation(accommodation_id)
);
CREATE TABLE judge_assignment (
    assignment_id INT PRIMARY KEY AUTO_INCREMENT,
    judge_id INT NOT NULL,
    event_id INT NOT NULL,
    FOREIGN KEY (judge_id) REFERENCES judge(judge_id),
    FOREIGN KEY (event_id) REFERENCES nascon_events(event_id)
);

CREATE TABLE score (
    score_id INT PRIMARY KEY AUTO_INCREMENT,
    judge_id INT NOT NULL,
    participant_id INT DEFAULT NULL,
    team_id INT DEFAULT NULL,
    event_id INT NOT NULL,
    round_id INT NOT NULL,
    score DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (judge_id) REFERENCES judge(judge_id),
    FOREIGN KEY (participant_id) REFERENCES participant(participant_id),
    FOREIGN KEY (team_id) REFERENCES team(team_id),
    FOREIGN KEY (event_id) REFERENCES nascon_events(event_id),
    FOREIGN KEY (round_id) REFERENCES round(round_id)
);

CREATE TABLE leaderboard (
    leaderboard_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    participant_id INT DEFAULT NULL,
    team_id INT DEFAULT NULL,
    final_score DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (event_id) REFERENCES nascon_events(event_id),
    FOREIGN KEY (participant_id) REFERENCES participant(participant_id),
    FOREIGN KEY (team_id) REFERENCES team(team_id)
);
CREATE TABLE payment (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_type ENUM('registration', 'sponsorship', 'accommodation') NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed') NOT NULL,
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);

CREATE TABLE finance_report (
    report_id INT PRIMARY KEY AUTO_INCREMENT,
    total_registrations DECIMAL(10,2),
    total_sponsorship DECIMAL(10,2),
    total_accommodation DECIMAL(10,2),
    total_payments DECIMAL(10,2),
    report_type ENUM('registration', 'sponsorship', 'accommodation', 'all') NOT NULL,
    generated_date DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE inventory (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    item_name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    alert_threshold INT DEFAULT 5
);

CREATE TABLE inventory_log (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    item_id INT NOT NULL,
    change_type ENUM('in', 'out'),
    quantity INT NOT NULL,
    changed_on DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES inventory(item_id)
);

CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('unread', 'read') DEFAULT 'unread'
);
CREATE TABLE user_sessions (
    session_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    auth_token VARCHAR(255),
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);

INSERT INTO event_category (category_name) VALUES 
('Tech Events'), 
('Business Competitions'), 
('Gaming Tournaments'), 
('General Events');

select * from nascon_events;



