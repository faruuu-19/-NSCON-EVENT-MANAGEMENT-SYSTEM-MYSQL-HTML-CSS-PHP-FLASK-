const db = require("../models/db");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const signup = async (req, res) => {
  const { full_name, email, password, phone, university, role_id } = req.body;

  if (!email || !password || !full_name) {
    return res.status(400).json({ message: "Required fields missing" });
  }

  try {
    const [existing] = await db.promise().query("SELECT * FROM users WHERE email = ?", [email]);
    if (existing.length) return res.status(409).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    await db.promise().query(
      `INSERT INTO users (full_name, email, password, phone, university, role_id)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [full_name, email, hashedPassword, phone, university, role_id]
    );

    res.status(201).json({ message: "User registered successfully" });
  } catch (err) {
    console.error("Signup error:", err);
    res.status(500).json({ message: "Server error" });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const [users] = await db.promise().query("SELECT * FROM users WHERE email = ?", [email]);
    if (!users.length) return res.status(401).json({ message: "Invalid credentials" });

    const user = users[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ message: "Invalid credentials" });

    console.log("JWT_SECRET from env:", process.env.JWT_SECRET);

    const token = jwt.sign(
      { user_id: user.user_id, role_id: user.role_id, full_name: user.full_name },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.status(200).json({ token, user: { user_id: user.user_id, role_id: user.role_id, full_name: user.full_name } });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = { signup, login };
