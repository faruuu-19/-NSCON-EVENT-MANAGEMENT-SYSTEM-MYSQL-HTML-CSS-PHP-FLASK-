const db = require("../models/db");

const getDashboardData = async (req, res) => {
  try {
    const [events] = await db.promise().query("SELECT * FROM events");
    res.status(200).json({ totalEvents: events.length });
  } catch (err) {
    console.error("Error in dashboard:", err);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  getDashboardData
};
