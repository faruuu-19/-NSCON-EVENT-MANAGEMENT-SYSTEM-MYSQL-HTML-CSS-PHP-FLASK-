const db = require("../models/db");

// Add a new venue
const addVenue = async (req, res) => {
  const { name, location, capacity } = req.body;
  try {
    await db.promise().query(
      `INSERT INTO venues (name, location, capacity) VALUES (?, ?, ?)`,
      [name, location, capacity]
    );
    res.status(201).json({ message: "Venue added successfully" });
  } catch (err) {
    console.error("Error adding venue:", err);
    res.status(500).json({ message: "Server error" });
  }
};

// Get all venues
const getVenues = async (req, res) => {
  try {
    const [rows] = await db.promise().query(`SELECT * FROM venues`);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch venues" });
  }
};

// Add event
const addEvent = async (req, res) => {
  const {
    event_name,
    description,
    rules,
    max_participants,
    registration_fee,
    date,
    time,
    venue_id,
    category_id
  } = req.body;
  const created_by = req.user.user_id; // from JWT

  try {
    await db.promise().query(
      `INSERT INTO events
        (event_name, description, rules, max_participants, registration_fee, date, time, venue_id, category_id, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        event_name,
        description,
        rules,
        max_participants,
        registration_fee,
        date,
        time,
        venue_id,
        category_id,
        created_by
      ]
    );
    res.status(201).json({ message: "Event created successfully" });
  } catch (err) {
    console.error("Error creating event:", err);
    res.status(500).json({ message: "Server error" });
  }
};

// Get all events (with venue/category info)
const getAllEvents = async (req, res) => {
  try {
    const [rows] = await db.promise().query(`
      SELECT e.*, v.name as venue_name, c.category_name
      FROM events e
      JOIN venues v ON e.venue_id = v.venue_id
      JOIN categories c ON e.category_id = c.category_id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch events" });
  }
};

// Add event round
const addEventRound = async (req, res) => {
  const { event_id, round_name, round_date, round_time } = req.body;
  try {
    await db.promise().query(
      `INSERT INTO event_rounds (event_id, round_name, round_date, round_time)
       VALUES (?, ?, ?, ?)`,
      [event_id, round_name, round_date, round_time]
    );
    res.status(201).json({ message: "Event round added successfully" });
  } catch (err) {
    res.status(500).json({ message: "Failed to add round" });
  }
};

// Get rounds for a specific event
const getEventRounds = async (req, res) => {
  const { event_id } = req.params;
  try {
    const [rows] = await db.promise().query(
      `SELECT * FROM event_rounds WHERE event_id = ?`,
      [event_id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch rounds" });
  }
};

// Update a venue
const updateVenue = async (req, res) => {
    const { venue_id } = req.params;
    const { name, location, capacity } = req.body;
  
    try {
      await db.promise().query(
        `UPDATE venues SET name = ?, location = ?, capacity = ? WHERE venue_id = ?`,
        [name, location, capacity, venue_id]
      );
      res.json({ message: "Venue updated successfully" });
    } catch (err) {
      console.error("Error updating venue:", err);
      res.status(500).json({ message: "Failed to update venue" });
    }
  };
  
  // Delete a venue
  const deleteVenue = async (req, res) => {
    const { venue_id } = req.params;
  
    try {
      await db.promise().query(
        `DELETE FROM venues WHERE venue_id = ?`,
        [venue_id]
      );
      res.json({ message: "Venue deleted successfully" });
    } catch (err) {
      console.error("Error deleting venue:", err);
      res.status(500).json({ message: "Failed to delete venue" });
    }
  };
// Update event
const updateEvent = async (req, res) => {
    const { event_id } = req.params;
    const {
      event_name, description, rules,
      max_participants, registration_fee, date, time,
      venue_id, category_id
    } = req.body;
  
    try {
      await db.promise().query(
        `UPDATE events SET 
          event_name = ?, description = ?, rules = ?, max_participants = ?, 
          registration_fee = ?, date = ?, time = ?, venue_id = ?, category_id = ?
        WHERE event_id = ?`,
        [
          event_name, description, rules, max_participants,
          registration_fee, date, time, venue_id, category_id, event_id
        ]
      );
      res.json({ message: "Event updated successfully" });
    } catch (err) {
      console.error("Update Event Error:", err);
      res.status(500).json({ message: "Failed to update event" });
    }
  };
  
  // Delete event
  const deleteEvent = async (req, res) => {
    const { event_id } = req.params;
    try {
      await db.promise().query(
        `DELETE FROM events WHERE event_id = ?`,
        [event_id]
      );
      res.json({ message: "Event deleted successfully" });
    } catch (err) {
      console.error("Delete Event Error:", err);
      res.status(500).json({ message: "Failed to delete event" });
    }
  };
  
  

module.exports = {
  addVenue,
  getVenues,
  addEvent,
  getAllEvents,
  addEventRound,
  getEventRounds,
  updateVenue,
  deleteVenue,
  deleteEvent,
  updateEvent

};
