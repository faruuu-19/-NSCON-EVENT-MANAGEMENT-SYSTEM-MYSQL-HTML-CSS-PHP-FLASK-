document.getElementById("signupForm").addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const full_name = document.getElementById("full_name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const phone = document.getElementById("phone").value;
    const university = document.getElementById("university").value;
    const role_id = document.getElementById("role_id").value;
  
    try {
      const res = await fetch("/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ full_name, email, password, phone, university, role_id }),
      });
  
      const data = await res.json();
      if (res.ok) {
        alert("Signup successful! Please login.");
        window.location.href = "/login.html";
      } else {
        document.getElementById("signupStatus").textContent = data.message || "Signup failed";
      }
    } catch (err) {
      console.error("Signup failed:", err);
    }
  });
  