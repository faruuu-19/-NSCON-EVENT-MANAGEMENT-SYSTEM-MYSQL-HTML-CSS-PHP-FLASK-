require("dotenv").config(); // MUST BE FIRST LINE
const express = require('express');
const session = require('express-session'); 
const path = require('path');
const bodyParser = require('body-parser');

const app = express(); 

const adminRoutes = require('./routes/admin'); 
const authRoutes = require('./routes/auth');   


const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Sessions
app.use(
  session({
    secret: "nascon_secret_key",
    resave: false,
    saveUninitialized: true,
  })
);

// Serve static files
app.use(express.static(path.join(__dirname, "public")));

// Default route
app.get("/", (req, res) => {
  res.redirect("/signup.html");
});

// Routes
app.use("/admin", adminRoutes);
app.use(express.static("public"));

app.use("/auth", authRoutes);
app.use("/event", require("./routes/event"));
app.use("/category", require("./routes/category")); 





// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
