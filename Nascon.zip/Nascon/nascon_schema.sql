
-- ======================================
-- DATABASE: NASCON Event Management DB
-- ======================================
CREATE DATABASE IF NOT EXISTS nascon;
USE nascon;

-- ===============================
-- 1. USER MANAGEMENT
-- ===============================
CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL
);

INSERT INTO roles (role_name) VALUES 
('Admin'), 
('Organizer'), 
('Participant'), 
('Sponsor'), 
('Judge');

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    university VARCHAR(100),
    role_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- ===============================
-- 2. EVENT & VENUE MANAGEMENT
-- ===============================
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) UNIQUE NOT NULL
);

INSERT INTO categories (category_name) VALUES 
('Tech Events'), 
('Business Competitions'), 
('Gaming Tournaments'), 
('General Events');

CREATE TABLE venues (
    venue_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    location VARCHAR(100),
    capacity INT
);

CREATE TABLE events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(100),
    description TEXT,
    rules TEXT,
    max_participants INT,
    registration_fee DECIMAL(10,2),
    date DATE,
    time TIME,
    venue_id INT,
    category_id INT,
    created_by INT,
    FOREIGN KEY (venue_id) REFERENCES venues(venue_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- Prevent overlapping events at same venue & time
CREATE UNIQUE INDEX idx_event_schedule ON events (venue_id, date, time);

CREATE TABLE event_rounds (
    round_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT,
    round_name VARCHAR(50),
    round_date DATE,
    round_time TIME,
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);

-- ===============================
-- 3. PARTICIPANTS & TEAMS
-- ===============================
CREATE TABLE teams (
    team_id INT AUTO_INCREMENT PRIMARY KEY,
    team_name VARCHAR(100),
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE participants (
    participant_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    team_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (team_id) REFERENCES teams(team_id)
);

CREATE TABLE event_registration (
    registration_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT,
    participant_id INT,
    team_id INT,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (participant_id) REFERENCES participants(participant_id),
    FOREIGN KEY (team_id) REFERENCES teams(team_id)
);

-- ===============================
-- 4. SPONSORSHIP MANAGEMENT
-- ===============================
CREATE TABLE sponsorship_packages (
    package_id INT AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(50),
    benefits TEXT,
    price DECIMAL(10,2)
);

INSERT INTO sponsorship_packages (package_name, benefits, price) VALUES 
('Title Sponsor', 'Main branding, Logo on banners, Announcements', 500000),
('Gold Sponsor', 'Logo on stage, Banners, Social Media', 300000),
('Silver Sponsor', 'Small logo placement, Posters', 150000),
('Media Partner', 'Media coverage and branding', 100000);

CREATE TABLE sponsors (
    sponsor_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    company_name VARCHAR(100),
    package_id INT,
    payment_status ENUM('Pending', 'Paid') DEFAULT 'Pending',
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (package_id) REFERENCES sponsorship_packages(package_id)
);

-- ===============================
-- 5. ACCOMMODATION MANAGEMENT
-- ===============================
CREATE TABLE accommodations (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_name VARCHAR(50),
    capacity INT,
    cost_per_night DECIMAL(10,2),
    is_available BOOLEAN DEFAULT TRUE
);

CREATE TABLE room_allocation (
    allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    participant_id INT,
    room_id INT,
    checkin_date DATE,
    checkout_date DATE,
    FOREIGN KEY (participant_id) REFERENCES participants(participant_id),
    FOREIGN KEY (room_id) REFERENCES accommodations(room_id)
);

-- ===============================
-- 6. PAYMENTS & FINANCE
-- ===============================
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(10,2),
    purpose VARCHAR(100),
    status ENUM('Pending', 'Paid') DEFAULT 'Pending',
    receipt_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ===============================
-- 7. JUDGE & EVALUATIONS
-- ===============================
CREATE TABLE judges_assigned (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    judge_id INT,
    event_id INT,
    FOREIGN KEY (judge_id) REFERENCES users(user_id),
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);

CREATE TABLE scores (
    score_id INT AUTO_INCREMENT PRIMARY KEY,
    judge_id INT,
    event_id INT,
    participant_id INT,
    score INT,
    feedback TEXT,
    FOREIGN KEY (judge_id) REFERENCES users(user_id),
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (participant_id) REFERENCES participants(participant_id)
);
