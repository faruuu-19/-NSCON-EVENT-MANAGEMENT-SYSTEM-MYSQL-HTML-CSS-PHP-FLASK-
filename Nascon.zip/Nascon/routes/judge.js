const express = require("express");
const router = express.Router();
const { assignJudges, getJudges } = require("../controllers/judgeController");
const { verifyToken } = require("../middleware/authMiddleware");

router.get("/all", verifyToken, getJudges);
router.post("/assign", verifyToken, assignJudges);

module.exports = router;
