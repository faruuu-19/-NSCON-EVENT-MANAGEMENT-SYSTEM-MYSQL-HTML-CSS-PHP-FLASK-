const express = require("express");
const router = express.Router();
const participantController = require("../controllers/participantController");

// Get all participants
router.get("/", participantController.getAllParticipants);

// Register individual participant to an event
router.post("/register/individual", participantController.registerIndividual);

// Register a team to an event
router.post("/register/team", participantController.registerTeam);

// Get all events a participant is registered for
router.get("/registered-events", participantController.getRegisteredEvents);

// Get leaderboard (participants and teams with final scores)
router.get("/leaderboard", participantController.getLeaderboard);

module.exports = router;
