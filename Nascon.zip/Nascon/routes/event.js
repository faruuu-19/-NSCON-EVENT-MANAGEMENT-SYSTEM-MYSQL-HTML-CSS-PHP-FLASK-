const express = require("express");
const router = express.Router();
const {
    addVenue,
    getVenues,
    addEvent,
    getAllEvents,
    addEventRound,
    getEventRounds,
    updateVenue,        // ✅ add this
    deleteVenue         // ✅ and this
  } = require("../controllers/eventController");
  
const { verifyToken } = require("../middleware/authMiddleware");

// Venue routes
router.post("/venues", verifyToken, addVenue);
router.get("/venues", getVenues);

// Event routes
router.post("/create", verifyToken, addEvent);
router.get("/all", getAllEvents);

// Rounds
router.post("/rounds", verifyToken, addEventRound);
router.get("/rounds/:event_id", getEventRounds);

router.post("/venues", verifyToken, addVenue);
router.put("/venues/:venue_id", verifyToken, updateVenue);
router.delete("/venues/:venue_id", verifyToken, deleteVenue);



module.exports = router;
