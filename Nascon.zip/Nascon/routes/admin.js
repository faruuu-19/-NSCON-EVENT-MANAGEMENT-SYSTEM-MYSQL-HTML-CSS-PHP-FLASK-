const express = require("express");
const router = express.Router();

const adminController = require("../controllers/adminController");

// This MUST point to a function exported from adminController
router.get("/dashboard", adminController.getDashboardData); 

module.exports = router;
